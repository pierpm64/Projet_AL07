export class Devise{
    constructor(public code:string="?",
                public name:string="?",
                public change:number=1){}
}