export class LoginResponse {
    username! : string;
    status! : boolean;
    message! : string;
    token! : string;
    roles! : string;
}