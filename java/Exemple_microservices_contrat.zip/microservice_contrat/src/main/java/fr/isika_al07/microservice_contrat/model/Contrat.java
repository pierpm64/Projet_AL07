package fr.isika_al07.microservice_contrat.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
public class Contrat {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	protected Integer id;
	
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate dateDebut;
	
	private Long numeroContrat;
	
	private Long numeroAssure;
	
	private Long numeroProduit;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public LocalDate getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(LocalDate dateDebut) {
		this.dateDebut = dateDebut;
	}

	public Long getNumeroContrat() {
		return numeroContrat;
	}

	public void setNumeroContrat(Long numeroContrat) {
		this.numeroContrat = numeroContrat;
	}

	public Long getNumeroAssure() {
		return numeroAssure;
	}

	public void setNumeroAssure(Long numeroAssure) {
		this.numeroAssure = numeroAssure;
	}

	public Long getNumeroProduit() {
		return numeroProduit;
	}

	public void setNumeroProduit(Long numeroProduit) {
		this.numeroProduit = numeroProduit;
	}
	
	

	public Contrat(LocalDate dateDebut, Long numeroContrat, Long numeroAssure, Long numeroProduit) {
		super();
		this.dateDebut = dateDebut;
		this.numeroContrat = numeroContrat;
		this.numeroAssure = numeroAssure;
		this.numeroProduit = numeroProduit;
	}
	
	

	public Contrat() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Contrat [id=");
		builder.append(id);
		builder.append(", dateDebut=");
		builder.append(dateDebut);
		builder.append(", numeroContrat=");
		builder.append(numeroContrat);
		builder.append(", numeroAssure=");
		builder.append(numeroAssure);
		builder.append(", numeroProduit=");
		builder.append(numeroProduit);
		builder.append("]");
		return builder.toString();
	}
	
}
