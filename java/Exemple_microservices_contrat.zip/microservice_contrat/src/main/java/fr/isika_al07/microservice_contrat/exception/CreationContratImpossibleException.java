package fr.isika_al07.microservice_contrat.exception;


import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)    
public class CreationContratImpossibleException extends RuntimeException {

	/**
	 * 
	 */
	public CreationContratImpossibleException(String message) {
		super(message);
	}

}