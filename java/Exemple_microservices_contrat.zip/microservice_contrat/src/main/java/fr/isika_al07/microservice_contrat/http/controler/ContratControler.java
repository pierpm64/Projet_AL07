package fr.isika_al07.microservice_contrat.http.controler;

import java.net.URI;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import fr.isika_al07.microservice_contrat.configuration.ApplicationPropertiesConfiguration;
import fr.isika_al07.microservice_contrat.dao.ContratRepository;
import fr.isika_al07.microservice_contrat.exception.ContratInexistantException;
import fr.isika_al07.microservice_contrat.exception.CreationContratImpossibleException;
import fr.isika_al07.microservice_contrat.model.Contrat;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping(path = "/contrat")
public class ContratControler {

	@Autowired
	ContratRepository contratRepository;

	@Autowired
	ApplicationPropertiesConfiguration appProperties;

	Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping(path = "/creerContrat")
	public ResponseEntity<Contrat> creerContrat(@RequestBody Contrat contrat) {
		log.info("contrat à créer dans ContratControler : " + contrat);
		Contrat nouveauContrat = contratRepository.save(contrat);

		if (nouveauContrat == null)
			throw new CreationContratImpossibleException("Impossible de créer le contrat.");

		return new ResponseEntity<Contrat>(nouveauContrat, HttpStatus.CREATED);
	}

	@PostMapping(path = "/creer")
	public ResponseEntity<Contrat> creer(@RequestBody Long numeroAssure) {
		Contrat nouveauContrat = new Contrat();
		nouveauContrat.setNumeroAssure(numeroAssure);
		nouveauContrat = contratRepository.save(nouveauContrat);

		if (nouveauContrat == null)
			throw new CreationContratImpossibleException("Impossible de créer le contrat.");

		log.info("--------------------------- Creation du contrat de l'assuré (numéro assuré) = {}", numeroAssure);

		return new ResponseEntity<Contrat>(nouveauContrat, HttpStatus.CREATED);
	}

	@PostMapping(path = "/ajouterContrat")
	public ResponseEntity<Void> creerAssure(@Valid @RequestBody Contrat contrat) {
		Contrat contratAjoute = contratRepository.save(contrat);

		if (contratAjoute == null)
			return ResponseEntity.noContent().build();

		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(contratAjoute.getId())
				.toUri();

		return ResponseEntity.created(uri).build();
	}

	@GetMapping(path = "/rechercherId/{id}")
	public Optional<Contrat> rechercherContratId(@PathVariable Integer id) {

		Optional<Contrat> contrat = contratRepository.findById(id);

		if (!contrat.isPresent())
			throw new ContratInexistantException("Ce contrat n'existe pas");

		return contrat;
	}

	@GetMapping(path = "/listerLesContrats")
	// public @ResponseBody Iterable<Contrat> getAllContrats() {
	public List<Contrat> getAllContrats() {
		log.info("getAllContrats() est appelée");
		Iterable<Contrat> iterContrats = contratRepository.findAll();
		return StreamSupport.stream(iterContrats.spliterator(), false).collect(Collectors.toList()).subList(0,
				appProperties.getLimiteNombreContrat());
	}

	@ApiOperation(value = "Recherche un Contrat grâce à son ID à condition que celui-ci existe.")
	@GetMapping(path = "/contratById/{id}")
	public Contrat rechercherContrarParId(@PathVariable Integer id) {
		log.info("rechercherContrarParId() est appelée");
		Optional<Contrat> monContrat = contratRepository.findById(id);
		if (monContrat.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Id de Contrat inconnu : " + id);
		}
		return monContrat.get();
	}

	@GetMapping(path = "/contratsByNumero/{numero}")
	public List<Contrat> getContratByNumero(@PathVariable Long numero) {
		log.info("getContratByNumero() est appelée");
		return contratRepository.findByNumeroContrat(numero);
	}

	@GetMapping(path = "/contratsByNumeroAssure/{numero}")
	public List<Contrat> getContratByNumeroAssure(@PathVariable Long numero) {
		log.info("getContratByNumero() est appelée");
		return contratRepository.findByNumeroAssure(numero);
	}

	@GetMapping(path = "/contratsByNumeroProduit/{numero}")
	public List<Contrat> getContratByNumeroProduit(@PathVariable Long numero) {
		log.info("getContratByNumeroProduit() est appelée");
		return contratRepository.findByNumeroProduit(numero);
	}
	
	   
    @GetMapping(path="/affecterNumeroProduit/{numeroAssure}/{numeroProduit}")
	public ResponseEntity<Contrat> affecterNumeroProduit(@PathVariable Long numeroAssure, @PathVariable Long numeroProduit) {
    	
    	log.info("-----------------ContratControleur > affecterNumeroProduit > numeroAssure : " + numeroAssure + " numeroProduit : " + numeroProduit);
    	
    	List<Contrat> contrats = contratRepository.findByNumeroAssure(numeroAssure);
    	
    	Contrat contrat = contrats.get(0);
    	log.info("-----------------ContratControleur > affecterNumeroProduit > findByNumeroAssure : " + contrat);
    	contrat.setNumeroProduit(numeroProduit);
    	contrat = contratRepository.save(contrat);
    	log.info("-----------------ContratControleur > affecterNumeroProduit > contrat : " + contrat);
        if(contrat == null) throw new CreationContratImpossibleException("Impossible de créer le contrat.");

        return new ResponseEntity<Contrat>(contrat, HttpStatus.CREATED);
    }
	
    @GetMapping(path="/finaliserContrat/{numeroAssure}/{numeroContrat}/{dateDebut}")
	public ResponseEntity<Contrat> finaliserContrat(@PathVariable Long numeroAssure, @PathVariable Long numeroContrat, 
			@PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate dateDebut) {
    	
    	log.info("-----------------ContratControleur > finaliserContrat > numeroAssure : " + numeroAssure + " numeroContrat : " + numeroContrat + " dateDebut " + dateDebut);
    	
    	List<Contrat> contrats = contratRepository.findByNumeroAssure(numeroAssure);
    	
    	// On suppose qu'un assure n'a qu'un seul contrat.
    	Contrat contrat = contrats.get(0);
    	contrat.setNumeroContrat(numeroContrat);
//    	try {
//    		Date date = new SimpleDateFormat("yyyy-MM-dd").parse(dateDebut);  
//    		contrat.setDateDebut(date);
//    	} catch (Exception e) {
//    		
//    	}
    	// LocalDate dateContrat= LocalDate.parse(dateDebut);
    	contrat.setDateDebut(dateDebut);
    	contrat = contratRepository.save(contrat);
    	log.info("-----------------ContratControleur > finaliserContrat > contrat : " + contrat);

        if(contrat == null) throw new CreationContratImpossibleException("Impossible de créer le contrat.");

        return new ResponseEntity<Contrat>(contrat, HttpStatus.CREATED);
    }
    
	@GetMapping(path="/rechercherNumeroAssure/{numeroAssure}")
	public List<Contrat> rechercherContratNumeroAssure(@PathVariable Long numeroAssure) {
		
		List<Contrat> contrats =  contratRepository.findByNumeroAssure(numeroAssure);
		
        if(contrats.isEmpty()) throw new ContratInexistantException("Ce contrat n'existe pas");

        return contrats;
	}

}
